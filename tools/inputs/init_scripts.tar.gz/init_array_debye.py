import numpy as np

infile = 'bumped_gauss.csv'
outfile = 'electrons_nocutout_debye.init'  #Name of file to be written

Lx = 2.574                 #size of domain in cm
Nx = 992
nspec = 1

# Data per species
Temps = [8.61e-5*10.0]       #eV
nspec = 1
#!-----------------------------!#

#Create the grid on -Lx/2 : Lx/2
dx = float(Lx) / float(Nx)
cellcenters = np.linspace(-0.5*float(Lx) + 0.5*dx, 0.5*float(Lx) - 0.5*dx, Nx)

# Create the file
fout = open(outfile, 'w') 

densvals_file = np.loadtxt(infile,delimiter=',')
print(densvals_file.shape)
shift = int(Nx / 4)
dens = np.zeros(Nx)

for species in range(0,nspec):
    fout.write("species\n")
    fout.write(str(species) + "\n")
    
    fout.write("dens\n")
    for i in range(Nx):
        # Calculate Maxwellian
        if(i < shift):
            dens[i] = densvals_file[0]
        elif(i > Nx - shift - 1):
            dens[i] = densvals_file[-1]
        else:
            dens[i] = densvals_file[i - shift]

    for i in range(Nx):
        fout.write(str(dens[i]) + "\n")            
    
    fout.write("velocity\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write('0.0' + "\n")
    
    fout.write("temperature\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write(str(Temps[species]) + "\n")
    
fout.write("Stop\n")
fout.close()
