""" 
Script for creating an initial condition to load into Multi-BGK
edit stuff below

Generates Gaussian with mean 0 and variance sigma (in cm) 

f(x) = \frac{1}{\sigma(2\pi)^{1/2}} e^{-x^2 / 2 sigma^2}

input file layout  
Do it by species, e.g. 
species
0
n
1.0 1.0 1.0 ... 1.0
velocity
1.0 1.0 1.0 ... 1.0
temperature
1.0 1.0 1.0 ... 1.0

"""

import numpy as np

#!-------- EDIT THESE ---------!#

Lx = 0.5*2.574                 #size of domain in cm
Nx = int(0.5*992)
nspec = 1

outfile = 'gauss_bump_deep_cutout_testsharp.init'  #Name of file to be written


# Data per species
dens_max = [1.3e9]  #1/cm^3
Temps = [8.61e-5]       #eV
std_dev = [0.129] # cm 
do_cutout = 1
cutout_a = 0.999
#cutout_w = 0.014
cutout_w = 0.005
p = 8.0
bump = 1e4

#!-----------------------------!#


#Create the grid on -Lx/2 : Lx/2
dx = float(Lx) / float(Nx)
cellcenters = np.linspace(-0.5*float(Lx) + 0.5*dx, 0.5*float(Lx) - 0.5*dx, Nx)
print(cellcenters.size)

# Create the file
fout = open(outfile, 'w') 

refmax = 0.0

for species in np.arange(0,nspec):
    fout.write("species\n")
    fout.write(str(species) + "\n")
    
    fout.write("dens\n")

    refmax = 0
    topmax = 0

    # grab ref params first
    for x in cellcenters:        
        # Calculate Maxwellian
        dens = dens_max[species] * (np.exp(-0.5 * (x / std_dev[species]) ** 2.0) - cutout_a * np.exp(-0.5 * (x / cutout_w) ** p) ) + bump
        #if(np.abs(x) < (cutout_w - dx)):
        #    dens = 1e0
        fout.write(str(dens) + "\n") 
    
    fout.write("velocity\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write('0.0' + "\n")
    
    fout.write("temperature\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write(str(Temps[species]) + "\n")
    
fout.write("Stop\n")
fout.close()
