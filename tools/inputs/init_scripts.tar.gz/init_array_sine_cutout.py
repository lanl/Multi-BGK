""" 
Script for creating an initial condition to load into Multi-BGK
edit stuff below

Generates Gaussian with mean 0 and variance sigma (in cm) 

f(x) = \frac{1}{\sigma(2\pi)^{1/2}} e^{-x^2 / 2 sigma^2}

input file layout  
Do it by species, e.g. 
species
0
n
1.0 1.0 1.0 ... 1.0
velocity
1.0 1.0 1.0 ... 1.0
temperature
1.0 1.0 1.0 ... 1.0

"""

import numpy as np

#!-------- EDIT THESE ---------!#

Lx = 1.272                 #size of domain in cm
Nx = 496
nspec = 1

outfile = 'sinusoid_cutout.init'  #Name of file to be written

# Data per species
Temps = [8.61e-5]       #eV

#!-----------------------------!#


#Create the grid on -Lx/2 : Lx/2
n0 = 1.0e6
dx = float(Lx) / float(Nx)
cellcenters = np.linspace(-0.5*float(Lx) + 0.5*dx, 0.5*float(Lx) - 0.5*dx, Nx)
#cellcenters_init = np.linspace(-0.25*float(Lx) + 0.5*dx, 0.25*float(Lx) - 0.5*dx, int(Nx/2))

# Create the file
fout = open(outfile, 'w') 

#densvals_file = np.loadtxt(infile,delimiter=',')
#print(densvals_file.shape)

from scipy.optimize import curve_fit

def gaussian(x, *p):
    a, x0, sigma = p
    return a * np.exp(-(x - x0)**2 / (2 * sigma**2))

def cosinusoid(x, Lx, n0):
    return n0*(2.0 + np.cos(np.pi * x / Lx))

for species in range(0,nspec):
    x_data = cellcenters
    #y_data = densvals_file[:,1]
        
    fout.write("species\n")
    fout.write(str(species) + "\n")
    
    fout.write("dens\n")
    for i in range(Nx):
        if(np.fabs(x_data[i]) < 0.05):
            fout.write(str(0.75*cosinusoid(x_data[i], 0.5*Lx, n0)) + "\n")
        else:
            fout.write(str(cosinusoid(x_data[i], 0.5*Lx, n0)) + "\n")
    
    fout.write("velocity\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write('0.0' + "\n")
    
    fout.write("temperature\n")
    for x in range(Nx):
        # Calculate Maxwellian        
        fout.write(str(Temps[species]) + "\n")
    
fout.write("Stop\n")
fout.close()
